require('./dist/angularfire');
module.exports = 'firebase';
